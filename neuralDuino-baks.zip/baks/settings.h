#ifndef __settings_h__
#define __settings_h__

#define NUM_INPUT_SYN 2 //no. of synapses to a perceptron
#define NUM_CONN_SYN 3 //no. of synapses to a perceptron
#define DISPLAY_ERROR 0
#define LEARNING_RATE 0.1
#define SPEED LEARNING_RATE
#define DEBUG 1
#endif