# neuralDuino
extendable perceptron library to build Artificial neural networks for Arduino

# Pre-Requisites
- Tested using Arduino v1.6.5(windows) on UNO and Mega but should work on any board really

# Instructions
- Start with the examples, read the comments and move from there
- for any problems post an issue

the project is also on hackaday - http://bit.ly/neuralDuino_H
