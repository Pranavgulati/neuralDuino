#ifndef __settings_h__
#define __settings_h__

#define NUM_SYN 4 //no. of synapses to a perceptron
#define DISPLAY_ERROR 0
#define LEARNING_RATE 0.1
#define MOMENTUM 0.1
#define SPEED LEARNING_RATE
#define DEBUG 0
#endif